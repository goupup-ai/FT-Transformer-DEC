from icecream import install

install()

from . import env  # noqa
from .data import *  # noqa
from .deep import *  # noqa
from .env import get_path  # noqa
from .metrics import *  # noqa
from .util import *  # noqa

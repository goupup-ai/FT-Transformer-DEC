from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from .models import TimeSeriesClusteringModel
from .Modules.dec import target_distribution, dec_loss
from .dataset.utils import prepare_dataset
from .dataset.data import FeatureConfig, MedicalTimeSeriesDataset, collate_patient_sequences


def initialize_kmeans(
    model: TimeSeriesClusteringModel,
    dataloader: DataLoader,
    device: torch.device,
) -> None:
    """Run encoder once over all data to initialize DEC cluster centers with KMeans."""
    model.eval()
    embeddings: List[torch.Tensor] = []
    with torch.no_grad():
        for batch in tqdm(dataloader, desc="KMeans init"):
            x_cont = batch["x_cont"].to(device)  # (B, T, Cc)
            x_cat = batch["x_cat"].to(device)  # (B, T, Ck)
            mask = batch["mask"].to(device)  # (B, T)
            times = batch["times"]

            h = model.encode(x_cont, x_cat, mask, times)  # (B, T, D)
            valid_mask = mask  # True for valid
            h_valid = h[valid_mask]  # (N_valid, D)
            embeddings.append(h_valid.cpu())

    all_embeddings = torch.cat(embeddings, dim=0)
    model.clustering.init_from_kmeans(all_embeddings)


def train_dec(
    static_csv_path: str,
    events_csv_path: str,
    feature_cfg: FeatureConfig,
    *,
    n_clusters: int,
    d_model: int = 128,
    max_seq_len: int = 128,
    batch_size: int = 32,
    n_epochs: int = 20,
    device: Optional[str] = None,
    lr: float = 1e-4,
    ft_kwargs: Optional[Dict] = None,
    time_transformer_cfg: Optional[Dict] = None,
    output_dir: str = "outputs_dec",
    save_every: int = 1,
):
    """End-to-end training of FT-Transformer + Time Transformer + DEC."""
    device_t = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))

    dataset = prepare_dataset(static_csv_path, events_csv_path, feature_cfg, max_seq_len)
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=True,
        collate_fn=collate_patient_sequences,
    )

    n_cont_features = (
        len(feature_cfg.cont_cols) + len(feature_cfg.static_cont_cols)
    )
    n_cat_features = (
        len(feature_cfg.cat_cols) + len(feature_cfg.static_cat_cols)
    )
    # for FT-Transformer we need cardinalities list for categorical features
    # here we do not distinguish dynamic/static categorical for the encoder
    cat_cardinalities: List[int] = []
    for col in feature_cfg.cat_cols:
        cat_cardinalities.append(
            int(dataset.artifacts.cat_vocab_maps[col].__len__())
        )
    for col in feature_cfg.static_cat_cols:
        cat_cardinalities.append(
            int(dataset.artifacts.static_cat_vocab_maps[col].__len__())
        )

    model = TimeSeriesClusteringModel(
        n_cont_features=n_cont_features,
        cat_cardinalities=cat_cardinalities,
        d_model=d_model,
        n_clusters=n_clusters,
        time_transformer_cfg=time_transformer_cfg,
        ft_kwargs=ft_kwargs,
    ).to(device_t)

    # KMeans initialization
    init_loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        collate_fn=collate_patient_sequences,
    )
    initialize_kmeans(model, init_loader, device_t)

    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    model.train()
    for epoch in range(1, n_epochs + 1):
        total_loss = 0.0
        n_batches = 0
        for batch in tqdm(dataloader, desc=f"Epoch {epoch}"):
            x_cont = batch["x_cont"].to(device_t)  # (B, T, Cc)
            x_cat = batch["x_cat"].to(device_t)  # (B, T, Ck)
            mask = batch["mask"].to(device_t)  # (B, T)
            times = batch["times"]

            h, q = model(x_cont, x_cat, mask, times)  # h: (B,T,D), q:(B,T,K)
            valid_mask = mask  # True for valid
            q_valid = q[valid_mask]  # (N_valid, K)

            p = target_distribution(q_valid.detach())
            loss = dec_loss(q_valid, p)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += float(loss.detach().cpu())
            n_batches += 1

        avg_loss = total_loss / max(1, n_batches)
        print(f"[Epoch {epoch}] DEC loss = {avg_loss:.4f}")

        # Optional: save checkpoint every `save_every` epochs
        if epoch % max(1, save_every) == 0:
            ckpt_path = output_path / f"model_epoch_{epoch}.pt"
            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "feature_cfg": feature_cfg.__dict__,
                },
                ckpt_path,
            )

    return model, dataset


def export_cluster_assignments(
    model: TimeSeriesClusteringModel,
    dataset: MedicalTimeSeriesDataset,
    *,
    feature_cfg: FeatureConfig,
    max_seq_len: int,
    batch_size: int = 32,
    device: Optional[str] = None,
    output_csv: str = "cluster_assignments.csv",
):
    """Export final cluster_id per event row."""
    device_t = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    model = model.to(device_t)
    model.eval()

    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        collate_fn=collate_patient_sequences,
    )

    records = []
    with torch.no_grad():
        for batch in tqdm(dataloader, desc="Export clusters"):
            x_cont = batch["x_cont"].to(device_t)
            x_cat = batch["x_cat"].to(device_t)
            mask = batch["mask"].to(device_t)
            times_list = batch["times"]
            patient_ids = batch["patient_ids"]

            _, q = model(x_cont, x_cat, mask, times_list)
            # predicted cluster id = argmax over K
            cluster_ids = q.argmax(dim=-1).cpu().numpy()  # (B, T)
            mask_np = mask.cpu().numpy()

            B, T = cluster_ids.shape
            for i in range(B):
                pid = patient_ids[i]
                times = times_list[i]
                for t_idx in range(min(len(times), T)):
                    if not mask_np[i, t_idx]:
                        continue
                    records.append(
                        {
                            feature_cfg.patient_id_col: pid,
                            feature_cfg.time_col: times[t_idx],
                            "cluster_id": int(cluster_ids[i, t_idx]),
                        }
                    )

    df = pd.DataFrame.from_records(records)
    df.to_csv(output_csv, index=False)
    print(f"Saved cluster assignments to {output_csv}")




from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
from torch import Tensor

from .Modules.ft_transformer import FTTransformer
from .Modules.time_transformer import TimeTransformer
from .Modules.dec import ClusteringLayer


class RowEncoderFTTransformer(nn.Module):
    """Wrap FTTransformer to work on (B, T, *) inputs.

    We treat each (patient, time) row as an independent sample for the FT-Transformer,
    then reshape back to (B, T, d_model).
    """

    def __init__(
        self,
        n_cont_features: int,
        cat_cardinalities: List[int],
        d_model: int,
        ft_kwargs: Optional[Dict] = None,
    ) -> None:
        super().__init__()
        ft_kwargs = dict(ft_kwargs or {})
        # Backbone (FTTransformerBackbone) expects at least d_block and n_blocks.
        # Here we set sensible defaults if the user didn't provide them.
        ft_kwargs.setdefault("d_block", d_model)
        ft_kwargs.setdefault("n_blocks", 3)
        ft_kwargs.setdefault("d_out", d_model)
        ft_kwargs.setdefault("ffn_d_hidden", None)
        ft_kwargs.setdefault("ffn_d_hidden_multiplier", 4 / 3)
        ft_kwargs.setdefault("attention_n_heads", 8)
        ft_kwargs.setdefault("attention_dropout", 0.1)
        ft_kwargs.setdefault("ffn_dropout", 0.1)
        ft_kwargs.setdefault("residual_dropout", 0.0)

        self.ft = FTTransformer(
            n_cont_features=n_cont_features,
            cat_cardinalities=cat_cardinalities,
            **ft_kwargs,
        )
        self.d_model = d_model
        self.n_cont_features = n_cont_features
        self.n_cat_features = len(cat_cardinalities)

    def forward(self, x_cont: Tensor, x_cat: Tensor, mask: Tensor) -> Tensor:
        """Encode per-row features.

        Args:
            x_cont: (B, T, Cc)
            x_cat: (B, T, Ck)
            mask:  (B, T) bool, True=valid
        Returns:
            z: (B, T, d_model)
        """
        B, T, _ = x_cont.shape
        # flatten valid positions
        x_cont_flat = x_cont.reshape(B * T, -1)
        x_cat_flat = x_cat.reshape(B * T, -1)
        z_flat = self.ft(x_cont_flat, x_cat_flat)  # (B*T, d_model)
        z = z_flat.reshape(B, T, self.d_model)
        # we keep padded positions as is; mask will be used later
        return z


class TimeSeriesClusteringModel(nn.Module):
    """End-to-end model: FT-Transformer row encoder + Time Transformer + DEC."""

    def __init__(
        self,
        *,
        n_cont_features: int,
        cat_cardinalities: List[int],
        d_model: int,
        n_clusters: int,
        time_transformer_cfg: Optional[Dict] = None,
        ft_kwargs: Optional[Dict] = None,
    ) -> None:
        super().__init__()
        self.row_encoder = RowEncoderFTTransformer(
            n_cont_features=n_cont_features,
            cat_cardinalities=cat_cardinalities,
            d_model=d_model,
            ft_kwargs=ft_kwargs,
        )
        tt_cfg = dict(time_transformer_cfg or {})
        tt_cfg.setdefault("d_model", d_model)
        self.time_encoder = TimeTransformer(**tt_cfg)
        self.clustering = ClusteringLayer(
            n_clusters=n_clusters, embedding_dim=d_model
        )

    def encode(
        self,
        x_cont: Tensor,
        x_cat: Tensor,
        mask: Tensor,
        times: Optional[List] = None,
    ) -> Tensor:
        """Return contextualized per-row embeddings h_t (B, T, d_model)."""
        z = self.row_encoder(x_cont, x_cat, mask)  # (B, T, d_model)
        h = self.time_encoder(z, mask=mask, times=times)  # (B, T, d_model)
        return h

    def forward(
        self,
        x_cont: Tensor,
        x_cat: Tensor,
        mask: Tensor,
        times: Optional[List] = None,
    ) -> Tuple[Tensor, Tensor]:
        """Return h and soft cluster assignments q for all valid positions.

        Returns:
            h: (B, T, d_model)
            q: (B, T, K) with padded positions arbitrary (should be ignored by mask)
        """
        h = self.encode(x_cont, x_cat, mask, times)
        B, T, D = h.shape
        K = self.clustering.n_clusters

        h_flat = h.reshape(B * T, D)
        q_flat = self.clustering(h_flat)  # (B*T, K)
        q = q_flat.reshape(B, T, K)
        return h, q




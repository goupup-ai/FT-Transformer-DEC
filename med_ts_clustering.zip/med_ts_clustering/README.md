## 医疗时序行级聚类框架说明（FT-Transformer + Time Transformer + DEC）

本目录提供了一套用于 **医疗时序数据行级事件聚类** 的完整 PyTorch 实现：

- **行级编码器**：`FTTransformer`（来自上级目录的 `ft_transformer.py`）
- **序列编码器**：`TimeTransformer`（对同一病人内部的时间序列做自注意力）
- **聚类模块**：`DEC`（Deep Embedded Clustering）
- **训练流程**：`trainer.py`（无监督训练）  
最终可以得到每条时序事件的 `cluster_id`。

---

## 1. 数据格式与配置

### 1.1 输入数据

- **静态特征表（每位病人一行）**  示例字段（列名）：
  - `subject_id`, `hadm_id`, `stay_id`
  - `gender`
  - `admission_age`, `charlson_comorbidity_index`
  - `height`, `weight`
  - `sofa`, `sapsii`, `oasis`
  - `ventilated`, `total_mv_hours`
  - `crrt_used`, `crrt_hours`
  - `icu_los_hours`
  - `hospital_expire_flag`, `mortality_28d_post_discharge`
  - `icu_first_gcs_total`, `icu_first_gcs_time`, `icu_first_gcs_source`

- **时序事件表（每位病人多行，按时间排序）**  示例字段（列名）：
  - `stay_id`, `hour`, `hour_index`
  - 生命体征与实验室指标：
    - `heart_rate`, `resp_rate`, `temperature`, `sbp`, `dbp`, `map`
    - `fio2`, `ph`, `pco2`, `po2`, `hco3`, `lactate`, `sao2`
    - `base_excess`, `tco2`, `sodium`, `potassium`, `chloride`, `calcium`
    - `hemoglobin`, `hematocrit`
  - 血管活性药物与液体输入输出：
    - `norepinephrine`, `dopamine`, `epinephrine`, `vasopressin`, `phenylephrine`
    - `in_volume_ml_hr`, `crystalloid_in_ml_hr`, `colloid_in_ml_hr`
    - `out_volume_ml_hr`, `urine_output_ml_hr`
  - 派生指标：
    - `pf_ratio`, `anion_gap`

两张表通过 `stay_id` 关联；`hour_index` 字段用于序列排序。

### 1.2 特征配置 `FeatureConfig`

你需要根据自己的字段名，配置特征信息（类定义在 `dataset` 子包中）：

```python
from med_ts_clustering.dataset.utils import FeatureConfig

feature_cfg = FeatureConfig(
    # 患者/序列 ID 与时间索引
    patient_id_col="stay_id",
    time_col="hour_index",
    # 动态连续特征（逐行变化，对应时序表中的生理/实验室/用药等数值列）
    cont_cols=[
        "heart_rate", "resp_rate", "temperature",
        "sbp", "dbp", "map",
        "fio2", "ph", "pco2", "po2", "hco3", "lactate", "sao2",
        "base_excess", "tco2",
        "sodium", "potassium", "chloride", "calcium",
        "hemoglobin", "hematocrit",
        "norepinephrine", "dopamine", "epinephrine",
        "vasopressin", "phenylephrine",
        "in_volume_ml_hr", "crystalloid_in_ml_hr", "colloid_in_ml_hr",
        "out_volume_ml_hr", "urine_output_ml_hr",
        "pf_ratio", "anion_gap",
    ],
    # 动态离散特征（如果有额外分类列，可在此处补充；当前示例为空）
    cat_cols=[],
    # 静态连续特征（每病人一行，对应静态表中的数值列）
    static_cont_cols=[
        "admission_age", "charlson_comorbidity_index",
        "height", "weight",
        "sofa", "sapsii", "oasis",
        "total_mv_hours",
        "crrt_hours",
        "icu_los_hours",
        "icu_first_gcs_total",
    ],
    # 静态离散特征（每病人一行，对应静态表中的类别列）
    static_cat_cols=[
        "gender",
        "ventilated",
        "crrt_used",
        "hospital_expire_flag",
        "mortality_28d_post_discharge",
        "icu_first_gcs_source",
    ],
)
```

> 注意  
> - 静态表必须包含 `stay_id` 和所有 `static_*` 列。  
> - 时序表必须包含 `stay_id`、`hour_index` 以及所有 `cont_cols` / `cat_cols` 列。  
> - 连续特征会自动做标准化（`StandardScaler`），类别特征会自动映射为整数 id。

---

## 2. 目录结构概览

- `models.py`  
  - `RowEncoderFTTransformer`：将 `(B, T, *)` 行级特征包装为 `FTTransformer` 输入并输出 `(B, T, d_model)`。  
  - `TimeSeriesClusteringModel`：串联 **FT-Transformer 行编码器 + Time Transformer 序列编码器 + DEC 聚类层**。

- `trainer.py`  
  - `train_dec(...)`：完整的无监督训练流程（包含 KMeans 初始化 + DEC KL 损失训练）。  
  - `export_cluster_assignments(...)`：将最终每条时序事件的 `cluster_id` 导出为 CSV。  
  - 依赖 `dataset` 子包（`prepare_dataset`）完成数据加载与预处理。

- `dataset/`（根据你的实现可能包含以下组件）  
  - `utils.py`：`FeatureConfig` 定义、`prepare_dataset` 工具函数（构造 `Dataset`）。  
  - 其他数据预处理相关模块（构建 `(B, T, feature)`、mask、time 列等）。

- `time_transformer.py`  
  - `TimeTransformer` 与时间/位置编码（按时间步编码序列）。

- `dec.py`  
  - `ClusteringLayer`、`target_distribution`、`dec_loss` 等 DEC 相关组件。

---

## 3. 快速开始训练

### 3.1 安装依赖

确保已安装 PyTorch 以及用于聚类与预处理的依赖：

```bash
pip install torch torchvision torchaudio
pip install pandas numpy scikit-learn tqdm
```

---

## 4. 训练过程细节（简要）

- **数据预处理**（由 `dataset` 子包完成）：
  - 按 `patient_id` 将静态表与时序表关联。
  - 按 `time` 对时序事件排序。
  - 连续特征做标准化；类别特征做整数编码。
  - 将每位病人的序列截断/填充到 `max_seq_len`，生成 `(B, T, feature)` 与 `mask`。

- **编码与聚类**（由 `TimeSeriesClusteringModel` + `DEC` 完成）：
  - 每一行事件经 **FT-Transformer 行级编码器** 得到 `z_t`。
  - 整个序列经 **Time Transformer** 得到带上下文的 `h_t`。
  - 所有 `h_t` 通过 **DEC 聚类层** 得到 soft assignment `q`；  
    根据 `q` 构造目标分布 `p`，最小化 `KL(p || q)` 训练 encoder 与聚类中心。

---

## 5. 训练输出与结果查看

- **模型检查点**：  
  `train_dec` 会把每个 epoch 的权重保存到 `output_dir`（默认：`outputs_dec`）中，例如：

  ```text
  outputs_dec/model_epoch_1.pt
  outputs_dec/model_epoch_2.pt
  ...
  ```

- **聚类结果 CSV**：  
  `export_cluster_assignments` 会输出形如：

  ```text
  patient_id,time,cluster_id
  p001,2020-01-01 10:00:00,3
  p001,2020-01-01 12:00:00,3
  p002,2020-02-01 09:00:00,1
  ...
  ```

  你可以基于该表进行可视化分析、病例回溯、代表行抽取等下游工作。

---

## 6. 关键可配置项一览

- **聚类相关**
  - `n_clusters`：聚类簇数 K。

- **模型规模**
  - `d_model`：行级/序列级 embedding 维度。
  - `time_transformer_cfg["n_layers"]`：Time Transformer 层数。
  - `time_transformer_cfg["n_heads"]`：多头注意力头数。
  - `time_transformer_cfg["dim_feedforward"]`：前馈层维度。

- **训练超参**
  - `batch_size`：batch 大小。
  - `n_epochs`：训练轮数。
  - `lr`：学习率。
  - `max_seq_len`：每个病人的最大序列长度。


